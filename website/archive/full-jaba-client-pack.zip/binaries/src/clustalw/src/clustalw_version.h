#ifndef CLUSTALW_VERSION_H
#define CLUSTALW_VERSION_H

#define CLUSTALW_NAME "ClustalW"

#define CLUSTALW_VERSION "2.0.12"

#endif

